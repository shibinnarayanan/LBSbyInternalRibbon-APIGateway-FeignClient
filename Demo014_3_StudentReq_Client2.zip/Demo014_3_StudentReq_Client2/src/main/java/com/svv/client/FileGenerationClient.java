package com.svv.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.svv.model.StudentResponse;

@FeignClient(name = "FILE-GENERATION")
public interface FileGenerationClient {
	
	@PostMapping(value = "/saveInfo", consumes = {"application/json","application/xml"})
	public abstract void invokeFileGeneration(@RequestBody StudentResponse stdResponse);

}
