package com.svv.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.svv.model.StudentResponse;

@FeignClient(name = "STUDENT-INFO")
public interface StudentInfoClient {
	
	@GetMapping(value = "/studentById/{id}")
	public abstract StudentResponse getStudentInfo(@PathVariable Integer id);

}
