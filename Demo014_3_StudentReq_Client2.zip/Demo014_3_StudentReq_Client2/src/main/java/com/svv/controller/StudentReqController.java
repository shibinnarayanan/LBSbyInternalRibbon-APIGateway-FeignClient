package com.svv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.svv.client.FileGenerationClient;
import com.svv.client.StudentInfoClient;
import com.svv.model.StudentResponse;

@RestController
public class StudentReqController {
	
	@Autowired
	StudentInfoClient stdInfoClient;
	@Autowired
	FileGenerationClient fileGeneration;
	
	@GetMapping(value = "/getStudentInfo/{id}")
	public StudentResponse getStudenDetails(@PathVariable Integer id)
	{
		StudentResponse stdResponse = stdInfoClient.getStudentInfo(id);
		
		if(stdResponse != null)
		{
			fileGeneration.invokeFileGeneration(stdResponse);
		}
		
		return stdResponse;
	}

}
