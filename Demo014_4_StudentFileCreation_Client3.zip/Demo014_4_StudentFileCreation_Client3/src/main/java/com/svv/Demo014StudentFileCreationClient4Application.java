package com.svv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class Demo014StudentFileCreationClient4Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo014StudentFileCreationClient4Application.class, args);
	}

}
