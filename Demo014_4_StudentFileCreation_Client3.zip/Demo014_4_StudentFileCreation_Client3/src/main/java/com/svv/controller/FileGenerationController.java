package com.svv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.svv.model.StudentResponse;
import com.svv.service.FileGenerationService;

@RestController
public class FileGenerationController {
	
	@Autowired
	FileGenerationService fileGenService;
	
	@PostMapping(value = "/saveInfo", consumes = {"application/json","application/xml"})
	public void saveStudenInfo(@RequestBody StudentResponse stdResp)
	{
		fileGenService.createFile(stdResp);
	}
	

}
