package com.svv.service;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Callable;

import com.svv.model.StudentResponse;

public class FileGeneration implements Runnable{
	
	private StudentResponse studResp;
	
	

	public FileGeneration(StudentResponse studResp) {
		super();
		this.studResp = studResp;
	}



	@Override
	public void run() {
		
		String name = studResp.getName();
		Integer id = studResp.getId();

		String fileSuffix = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());

		String fileName = "C:\\Users\\HP Pavilion\\Desktop\\tempLoc\\" +id+"_"+name + "_" + fileSuffix + ".txt";

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(fileName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PrintWriter printWriter = new PrintWriter(fileWriter);
		printWriter.println("Student Id : " + studResp.getId());
		printWriter.println("Student Name : " + studResp.getName());
		printWriter.println("Student Address : " + studResp.getAddress());
		printWriter.println("Course : " + studResp.getCourse());
		printWriter.println("");
		printWriter.println("Port number : " + studResp.getPort());
		printWriter.close();
	}



}
