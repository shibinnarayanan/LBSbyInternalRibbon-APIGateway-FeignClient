package com.svv.service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.svv.model.StudentResponse;

@Service
public class FileGenerationService {

	

	public void createFile(StudentResponse stdResponse) {
		ExecutorService execServ = Executors.newFixedThreadPool(5);
		execServ.execute(new FileGeneration(stdResponse));
	}

}
