package com.svv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.svv.model.Student;
import com.svv.model.StudentResponse;
import com.svv.util.StudentDB;

@RestController
public class StudentController {
	
    @Autowired
	Environment enviornment;
	
	@GetMapping(value = "/studentById/{id}")
	public StudentResponse getStudent(@PathVariable Integer id)
	{
		String port = enviornment.getProperty("server.port");
		
		List<Student> list = StudentDB.getList();
		
		for(Student stud : list)
		{
			
			if(stud.getId() == id)
			{
				StudentResponse stdResp = new StudentResponse();
				stdResp.setId(stud.getId());
				stdResp.setName(stud.getName());
				stdResp.setAddress(stud.getAddress());
				stdResp.setCourse(stud.getCourse());
				stdResp.setPort(port);		
				return stdResp;
			}
		}
		
		return null;
		
	}

}
