package com.svv.util;

import java.util.ArrayList;
import java.util.List;

import com.svv.model.Student;

public class StudentDB {

	public static List<Student> getList()
	{
		
		List<Student> stdList = new ArrayList<Student>();
		
		stdList.add(new Student(101,"Shibin","India","Engineering"));
		stdList.add(new Student(102,"Ram","India","Engineering"));
		stdList.add(new Student(103,"Arun","India","Engineering"));
		stdList.add(new Student(104,"Jagan","India","Engineering"));
		stdList.add(new Student(105,"Mohan","India","Engineering"));
		
		return stdList;
	}

}
